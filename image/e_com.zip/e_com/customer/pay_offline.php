<div class="rx">
	<center>
		<h1>Pay Offline Using below method</h1>
		<p>If you have any questions, please feel free to <a href="contactus.php">contact us</a>, ourcustmer service center is working for you 24/7.</p>
	</center>
	<hr>
	<div class="table-responsive">
		<table class="table table-border table-hover table-striped">
			<thead>
				<tr class="account">
					<th>Bank Account Number</th>
					<th>Paypal Id</th>
					<th>Payumoney</th>
					<th>Paytm Number</th>
					</tr>
			</thead>
			<tbody>
				<tr class="account">
					<td>2345617894325679</td>
					<td>abc@paypal.com</td>
					<td>************</td>
					<td>+918295413790</td>
				</tr>
			</tbody>
			<tbody>
				<tr class="account">
					<td>2345617894325679</td>
					<td>abc@paypal.com</td>
					<td>************</td>
					<td>+918295413790</td>
				</tr>
			</tbody>
			<tbody>
				<tr class="account">
					<td>2345617894325679</td>
					<td>abc@paypal.com</td>
					<td>************</td>
					<td>+918295413790</td>
				</tr>
			</tbody>
			<tbody>
				<tr class="account">
					<td>2345617894325679</td>
					<td>abc@paypal.com</td>
					<td>************</td>
					<td>+918295413790</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>