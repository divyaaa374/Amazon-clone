<!-- footer section starts  -->

<section class="footer" id="footer">

    <div class="container">

        <div class="boxes">
            <h2>about us</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique expedita molestiae distinctio facere beatae velit, maiores ullam molestias necessitatibus sapiente.</p>
        </div>

     
            
       <div class="boxes">
            <h3>links</h3>
            <a href="#">facebook</a>
            <a href="#" class="fas fa-user"> user </a>
            <a href="#">featured</a>
            <a href="#">gallery</a>
            <a href="#">deal</a>
        </div>


        <div class="boxes">
            <h3>contact us</h3>
            <p> <i class="fas fa-home"></i>
                ch. charan singh market<br>
                near bus stand hansi<br> haryana<br>  
                india - 125033
            </p>
            <p> <i class="fas fa-phone"></i>
                +919728397211
            </p>
            <p> <i class="fas fa-globe"></i>
                gscosmetics@gmail.com
            </p>
        </div>
 <h4>Stay In Touch</h4>
                <p class="social">
                    <a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-twiter"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-envlope"></i></a>
                </p>
    </div>

<h1 class="credit"> &copy; <span>2021 Dr. Rakesh Kumar</span> | all rights reserved. </h1>

</section>

<!-- footer section ends -->